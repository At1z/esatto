package com.atis.esatto;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EsattoApplication {

	public static void main(String[] args) {
		SpringApplication.run(EsattoApplication.class, args);
	}

}
